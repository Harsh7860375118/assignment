package com.org.lab1.employee.service.interfac;

import com.org.lab1.employee.Employee;

public interface EmployeeServiceInterface {
	Employee getEmpById(int id);
	
}
