package com.org.lab1.employee.dao.interfac;

import com.org.lab1.employee.Employee;

public interface EmployeeDaoInterface {
	public Employee getEmpById(int id);
}
